<?php
require_once '../config.php';
require_once '../rcp_scenarios.php';

header('Content-Type: application/json; charset=utf-8');

// Получаем данные
$data = json_decode(file_get_contents('php://input'), true);
$session_id = intval($data['session_id'] ?? 0);
$user_message = trim($data['message'] ?? '');
$module_type = $data['module_type'] ?? 'uncertainty';

// Валидация
if (empty($user_message)) {
    echo json_encode(['error' => 'Пустое сообщение', 'rcp_response' => ''], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($session_id <= 0) {
    echo json_encode(['error' => 'Неверный ID сессии', 'rcp_response' => ''], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // Сохраняем сообщение пользователя
    $stmt = $pdo->prepare("INSERT INTO dialog_messages (session_id, sender, message_text) VALUES (?, 'user', ?)");
    $stmt->execute([$session_id, $user_message]);
    
    // Получаем историю сообщений
    $stmt = $pdo->prepare("SELECT sender, message_text FROM dialog_messages WHERE session_id = ? ORDER BY created_at ASC");
    $stmt->execute([$session_id]);
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Считаем количество сообщений пользователя
    $userMessages = array_filter($messages, fn($m) => $m['sender'] === 'user');
    $messageCount = count($userMessages);
    
    // Получаем сценарий
    $scenario = getScenario($module_type);
    
    // Определяем текущий этап
    $stageOrder = array_keys($scenario['stages']);
    $stageIndex = min(floor(($messageCount - 1) / 2), count($stageOrder) - 1);
    $currentStage = $stageOrder[max(0, $stageIndex)];
    
    // Получаем вопрос для текущего этапа
    $rcp_response = getQuestionForStage($scenario, $currentStage, $user_message);
    
    // Сохраняем ответ РЦП
    $stmt = $pdo->prepare("INSERT INTO dialog_messages (session_id, sender, message_text) VALUES (?, 'rcp', ?)");
    $stmt->execute([$session_id, $rcp_response]);
    
    // Обновляем длительность
    $stmt = $pdo->prepare("UPDATE dialog_sessions SET duration_seconds = TIMESTAMPDIFF(SECOND, started_at, NOW()) WHERE id = ?");
    $stmt->execute([$session_id]);
    
    echo json_encode([
        'success' => true,
        'rcp_response' => $rcp_response,
        'current_stage' => $currentStage,
        'message_count' => $messageCount
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    echo json_encode([
        'error' => 'Ошибка сервера: ' . $e->getMessage(),
        'rcp_response' => 'Извини, произошла техническая ошибка. Попробуй ещё раз.'
    ], JSON_UNESCAPED_UNICODE);
}
?>