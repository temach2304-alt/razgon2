<?php
require_once '../config.php';

header('Content-Type: application/json; charset=utf-8');

$data = json_decode(file_get_contents('php://input'), true);
$session_id = intval($data['session_id'] ?? 0);

try {
    $stmt = $pdo->prepare("UPDATE dialog_sessions SET is_completed = 1, ended_at = NOW() WHERE id = ?");
    $stmt->execute([$session_id]);
    
    echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
?>