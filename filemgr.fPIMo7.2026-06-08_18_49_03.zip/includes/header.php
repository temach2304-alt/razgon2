<?php
// Проверка и запуск сессии
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Установка заголовков
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Рефлексивная Цифровая Персона'; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container">
        <?php if (isset($_SESSION['user_id'])): ?>
        <div class="main-header">
            <h1><?php echo $header_title ?? 'Рефлексивная Цифровая Персона'; ?></h1>
            <p><?php echo $header_subtitle ?? 'Курс «Я и мой выбор»'; ?></p>
            <div class="user-nav">
                <a href="profile.php" class="btn-secondary">👤 Профиль</a>
                <a href="logout.php" class="btn-secondary">🚪 Выход</a>
            </div>
        </div>
        <?php endif; ?>